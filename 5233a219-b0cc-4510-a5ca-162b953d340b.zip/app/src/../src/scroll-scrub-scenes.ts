import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";

export const scrollScrubTheme: ScrollScrubTheme = {
  accent: "#F4D21F",
  background: "#111111",
  ink: "#F7F7F2",
  muted: "#C2C2BA",
};

export const scrollScrubScenes: ScrollScrubScene[] = [
  {
    id: "task-desk",
    label: "The idea",
    kicker: "SMALL DIGITAL TASKS FOR SOLO FOUNDERS",
    title: "Got a small business task? I’ll handle it.",
    body: "I help founders clean up website copy, organize lead lists and documents, and turn rough notes into clear workflows. One defined task at a time, starting at $5.",
    tags: ["Copy + website fixes", "Lead lists + documents", "Simple AI workflows"],
    clip: "/assets/world/scene-01.mp4",
    mobileClip: "/assets/world/scene-01-mobile.mp4",
    poster: "/assets/world/scene-01-desktop-poster.png",
    mobilePoster: "/assets/world/scene-01-mobile-poster.png",
    scroll: 3.6,
    linger: 0.08,
    objectPosition: "50% 50%",
    mobileObjectPosition: "50% 50%",
  },
];
